var stb;
  try {
    stb = gSTB;
  }
  catch(e){
  }

